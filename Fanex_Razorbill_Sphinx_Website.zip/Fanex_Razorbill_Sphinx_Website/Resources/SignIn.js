﻿/*
* Created 20100113@Lee - Sign-in javascript functions
* Revision ?@? - ...
*
*/
var CurrentLanguageId = 0;

var LanguagesId = new Array(0, 1, 2, 3, 4, 5, 6);
var Languages = new Array("en-US", "zh-TW", "ja-JP", "th-TH", "zh-CN", "ko-KR", "vi-VN");
var LanguageMessages = new Array({
    errUserName: "Please input username and password",
    errValidCode: "You must input validation code."
}, {
    errUserName: "請輸入會員名字及密碼",
    errValidCode: "您必须输入正确验证码"
}, {
    errUserName: "ユーザー名とパスワードを入力してください",
    errValidCode: "You must input validation code."
}, {
    errUserName: "โปรดใส่ชื่อผู้ใช้และรหัสผ่าน",
    errValidCode: "คุณต้องใส่หมายเลขที่ใช้ในการตรวจสอบ"
}, {
    errUserName: "请输入账号及密码",
    errValidCode: "您必須輸入正確驗證碼"
}, {
    errUserName: "사용자명과 비밀번호를 입력해주세요",
    errValidCode: "확인코드를 입력해주세요."
}, {
    errUserName: "Vui lòng điền Tên đăng nhập và Mật khẩu",
    errValidCode: "Bạn phải nhập mã xác thực."
});

function SelectLanguage(value) {
    var flagBgX = 0;
    var flagWidth = 24
    if (value == LanguagesId[0]) // English
    {
        SetValue(value, 'Username', 'Password', 'Login', 'Recommended Browsers', "Show password");
    } else if (value == LanguagesId[1]) // Chinese traditional
    {
        SetValue(value, '用户名', '密碼', '登入', 'Recommended Browsers', "顯示密碼");
        flagBgX = flagWidth * 5;
    } else if (value == LanguagesId[4]) // Chinese simplified
    {
        SetValue(value, '用户名', '密码', '注册', 'Recommended Browsers', "显示密码");
        flagBgX = flagWidth * 5;
    } else if (value == LanguagesId[2]) // Japanese
    {
        SetValue(value, 'ユーザー名', 'パスワード', '入力', 'Recommended Browsers', "Show password");
        flagBgX = flagWidth * 4;
    } else if (value == LanguagesId[3]) // Thailand
    {
        SetValue(value, 'ชื่อผู้ใช้ระบบ', 'รหัสผ่าน', 'เข้าระบบ', 'Recommended Browsers', "แสดง");
        flagBgX = flagWidth * 3;
    } else if (value == LanguagesId[5]) // Korean
    {
        SetValue(value, '사용자 이름', '비밀번호', '로그인', 'Recommended Browsers', "비밀번호 나타내기");
        flagBgX = flagWidth * 2;
    }
    else if (value == LanguagesId[6]) // Vietnamese
    {
        SetValue(value, 'Tên đăng nhập', 'Mật khẩu', 'Đăng nhập', 'Recommended Browsers', "Hiển thị mật khẩu");
        flagBgX = flagWidth * 1;
    }

    $('spnLanguage').style.backgroundPosition = flagBgX + 'px 0px';
    $("errmsg").innerHTML = '';

    if (window._isUsingCustomScript) {
        $("errmsg").innerHTML = '&nbsp;';
        window.CustomSelectLanguage();
    }
}

function SetValue(language, username, pwd, login, browser, pwdHint) {
    $('hidLanguage').value = Languages[language];
    $('spnUserName').innerHTML = username;
    $('spnPassWord').innerHTML = pwd;
    $('btnLogin').value = login;

    $('divBrowser').innerHTML = browser;
    $('selLanguage').value = language;
    $('showPwdLabel').innerHTML = pwdHint;
    setCookie('LANGUAGE', language, 30);
    CurrentLanguageId = language;

    if (window._isUsingCustomScript) {
        window.CustomUpdateLoginPage(language, username, pwd, login, browser, pwdHint);
    }
}

function DoLogin() {
    var errObj = LanguageMessages[CurrentLanguageId];
    if ($('txtUserName').value == "") {
        $("errmsg").innerHTML = errObj.errUserName;
        $('txtUserName').focus();
        return false;
    }
    if ($('txtPassWord').value == "") {
        $("errmsg").innerHTML = errObj.errUserName;
        $('txtPassWord').focus();
        return false;
    }
    if ($('txtCaptcha').value == "") {
        $("errmsg").innerHTML = errObj.errValidCode;
        $('txtCaptcha').focus();
        return false;
    }

    $('btnLogin').disabled = true;
    $('btnLogin').className = 'buttondisable';
    $('txtPassWord').value = $('txtPassWord').value.ec(_page.captcha).hc();

    try {
        setCookie2("__utms", _page.__utms, 1, "/", "." + _page.domain, "");
    } catch (exception) {
    }

    var oldPlaceHolderLanguage;
    var oldPlaceHolder_IsSelect;
    if (_isUsingCustomScript) {
        oldPlaceHolderLanguage = placeHolderLanguage;
        oldPlaceHolder_IsSelect = placeHolder_IsSelect;
    }

    setCookie("ssl", location.href.indexOf('https://') == 0, 30);
    document.fLogin.submit();

    if (_isUsingCustomScript) {
        placeHolderLanguage = oldPlaceHolderLanguage;
        placeHolder_IsSelect = oldPlaceHolder_IsSelect;
    }

    return true;
}

function GetValidateImage() {
    var objDate = new Date();
    $("imgCode").src = "Handlers/Captcha.ashx?code=" + objDate.getMilliseconds();
    setTimeout(GetValidateImage, 120000);
}

function InitLogin() {
    // Do not allow wrapping sign-in page
    if (window.parent != window) {
        window.parent.location = location.href;
    }

    (function () {
        // Insert show password check box
        var td = $('txtPassWord').parentNode;
        var div = document.createElement("DIV");
        var checkbox = document.createElement("INPUT");
        checkbox.setAttribute('type', 'checkbox');
        checkbox.id = 'showPwdChk';
        var label = document.createElement("LABEL");
        label.setAttribute('for', checkbox.id);
        label.id = 'showPwdLabel';

        div.style.padding = '2px';
        $('spnPassWord').parentNode.vAlign = 'top';

        div.appendChild(checkbox);
        div.appendChild(label);
        div.setAttribute('id', 'boxShowPassword');

        var txtPassWord = $('txtPassWord');
        var pwdMask = document.createElement("INPUT");
        pwdMask.setAttribute('id', 'txbShowPassword');
        pwdMask.setAttribute('type', 'text');
        pwdMask.className = 'tb';
        pwdMask.style.display = 'none';
        td.appendChild(pwdMask);

        if (window._isUsingCustomScript) {
            $('showPwdChk').onclick = function () {
                txtPassWord.style.display = this.checked ? 'none' : 'block';
                pwdMask.style.display = !this.checked ? 'none' : 'block';
                if (window._isUsingCustomScript) {
                    ShowHideShowPasswordTextBox();
                }
            }
        } else {
            td.appendChild(div);
            checkbox.onclick = function () {
                txtPassWord.style.display = this.checked ? 'none' : 'block';
                pwdMask.style.display = !this.checked ? 'none' : 'block';
                if (window._isUsingCustomScript) {
                    ShowHideShowPasswordTextBox();
                }
            }
        }

        $('divBrowser').style.display = 'none';
        txtPassWord.onchange = function () {
            pwdMask.value = this.value;
        }

        pwdMask.onchange = function () {
            txtPassWord.value = this.value;
        }
    })();

    var language = getCookie('LANGUAGE');
    if (!language) language = _page.language;

    SelectLanguage(language);
    GetValidateImage();

    if (typeof _page.errCode != 'undefined' && _page.errCode != 0) {
        $("errmsg").innerHTML = _page.errMsg;
        if (_page.errCode == 101) {
            $('txtCaptcha').focus();
        }
    }

    if ($('txtUserName').value == "") {
        $('txtUserName').focus();
    }

    $('txtPassWord').setAttribute('autocomplete', 'off');
    if (window._isUsingCustomScript) {
        window.CustomInitLoginPage();
    }
}

// Register start up
_addEvent(window, "load", InitLogin);





